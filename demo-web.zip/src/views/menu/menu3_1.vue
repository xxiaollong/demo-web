<template>
<div class="login-container">
    <h1>{{pageName}}</h1>
  </div>
</template>

<script>
  export default {
    name: 'Menu3_1',
    data() {
      return {
        pageName: '菜单3-1'
      }
    }
  }
</script>

