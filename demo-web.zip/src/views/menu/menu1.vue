<template>
  <div class="login-container">
    <h1>{{pageName}}</h1>
  </div>
</template>

<script>
  export default {
    name: 'Menu1',
    data() {
      return {
        pageName: '菜单1'
      }
    }
  }
</script>

