<template>
<div class="login-container">
    <h1>{{pageName}}</h1>
  </div>
</template>

<script>
  export default {
    name: 'Menu3_3',
    data() {
      return {
        pageName: '菜单3-3'
      }
    }
  }
</script>

